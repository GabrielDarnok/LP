#Determinando a lista
Lista = [1,2,4,2,1]

soma = 0

#Logica para identificar quais são pares
for n in Lista:
    if n%2 == 0:
        soma = soma +n

#Retornando a soma dos valores pares
print("A soma dos numeros pares é igual a:", soma)