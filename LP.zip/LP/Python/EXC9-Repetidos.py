#Definir a lista
Lista = [1,1,3,8,9,9]

Lista_Repetidos = []

#Logica para identificar quais são repetidos
for n in Lista:
    if Lista.count(n) > 1 and n not in Lista_Repetidos:
        Lista.append(n)

#Retorna valor
print("Os valores repetidos são:", Lista_Repetidos)