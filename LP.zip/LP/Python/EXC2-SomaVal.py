a = int(input("Digite um numero: "))
b = int(input("Digite um numero: "))

print("\n------------------------------------------------")

print("A soma dos valores digitados é igual a: ", a + b)