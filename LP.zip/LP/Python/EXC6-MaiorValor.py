#input do primeiro numero
a = int(input("Digite um numero: "))
#input do segundo numero
b = int(input("Digite um numero: "))
#input do terceiro numero
c = int(input("Digite um numero: "))


if(a > b) and (a > c):
    maior = a
    print("O maior valor é:", maior)
elif(b > a) and (b > c):
    maior = b
    print("O maior valor é:", maior)
else:
    maior = c
    print("O maior valor é:", maior)
