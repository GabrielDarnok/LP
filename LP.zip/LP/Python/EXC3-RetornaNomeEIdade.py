#Input do nome
nome = input("Digite seu nome: ")
#Input da idade
idade = input("Digite sua idade: ")

#printando valores
print("Olá",nome ,"você tem",idade, "anos.\n")