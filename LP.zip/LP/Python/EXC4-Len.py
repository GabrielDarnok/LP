#Input da palavra
palavra = input("Digite uma palavra: ")

#Retornando o valor da quantidade de letras.
print("A palavra", palavra,"tem", len(palavra),"letras.\n")
