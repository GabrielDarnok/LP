#input do numero
n = int(input("Digite um numero: "))

#Logica para saber se impar ou par
if(n%2 == 0):
    print("O valor", n,"é par")
else:
    print("O valor",n,"é impar")
