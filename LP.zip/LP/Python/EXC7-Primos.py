#input do primeiro numero
limite = int(input("Digite o limite: "))

#Logica para identificar os primos
for num in range(2, limite+1):
    for i in range(2, num):
        if num % i == 0:
            break
    else:
        print(num)