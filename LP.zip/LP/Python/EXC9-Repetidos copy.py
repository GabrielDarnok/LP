lista = [2, 5, 2, 7, 10, 13, 16, 20, 5, 7]
repetidos = []
for num in lista:
    if lista.count(num) > 1 and num not in repetidos:
        repetidos.append(num)
print("Os números que se repetem são:", repetidos)